package com.codingdojo.objectmasterone;

public class Ninja extends Human {
	public Ninja() {
		
	}
	
	@Override
    public String toString(){
        return "Wizard{" + "Strength= " + strength + " Intelligence= " + intelligence + " Stealth= " + stealth + " Health=" + health +"}";
    }

}
